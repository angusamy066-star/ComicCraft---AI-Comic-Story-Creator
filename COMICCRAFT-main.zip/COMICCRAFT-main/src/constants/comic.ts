export const SETTINGS = [
  "Enchanted Forest",
  "School",
  "City",
  "Space",
  "Fantasy Kingdom",
  "Custom",
];

export const TONES = [
  "Funny",
  "Dramatic",
  "Light-hearted",
  "Poetic",
  "Adventure",
  "Mysterious",
];

export const ART_STYLES = [
  "Anime",
  "Comic Book",
  "Pixel Art",
  "Realistic",
  "Cartoon",
  "Fantasy",
];

export const LOADING_STEPS = [
  { key: "outline", label: "Generating story outline..." },
  { key: "story", label: "Creating characters & dialogue..." },
  { key: "images", label: "Generating comic panels..." },
  { key: "layout", label: "Finalizing your comic..." },
  { key: "done", label: "Your comic is ready!" },
];

export const DEMO_COMIC_DATA = {
  story_prompt:
    "A brave fox discovers a mysterious glowing door inside an enchanted forest.",
  character_name: "Leo",
  setting: "Enchanted Forest",
  tone: "Adventure",
  art_style: "Comic Book",
};

export const UNSPLASH_THEMES: Record<string, string> = {
  "Enchanted Forest": "enchanted+forest+fantasy+magic",
  School: "school+adventure+kids+fantasy",
  City: "city+night+adventure+superhero",
  Space: "space+galaxy+astronaut+adventure",
  "Fantasy Kingdom": "fantasy+castle+kingdom+magic",
  Custom: "adventure+fantasy+hero",
};
