import { PanelOutline, PanelStory, GenerationInput } from "@/types/comic";

const GEMINI_API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

async function callGemini(apiKey: string, prompt: string): Promise<string> {
  const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.8,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 4096,
      },
    }),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err?.error?.message || "Gemini API error");
  }

  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

function extractJSON(text: string): string {
  const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
  if (jsonMatch) return jsonMatch[1];
  const objMatch = text.match(/(\[[\s\S]*\]|\{[\s\S]*\})/);
  if (objMatch) return objMatch[1];
  return text;
}

export async function generateOutline(
  apiKey: string,
  input: GenerationInput
): Promise<PanelOutline[]> {
  const prompt = `You are a comic book writer. Generate EXACTLY 5 comic panel outlines for the following story.

Story Prompt: "${input.story_prompt}"
Main Character: "${input.character_name}" 
Setting: "${input.setting}"
Story Tone: "${input.tone}"
Art Style: "${input.art_style}"

Return ONLY a valid JSON array with exactly 5 objects. Each object must have:
- "panel_number": integer (1-5)
- "title": string (short panel title, max 6 words)
- "scene_description": string (2-3 sentences describing the scene)
- "image_prompt": string (detailed visual prompt for image generation including character appearance, art style "${input.art_style}", setting, lighting, mood)

The image_prompt for every panel MUST include: "${input.character_name}" as the main character, "${input.setting}" as the setting, "${input.art_style}" art style.

Return ONLY the JSON array, no other text.`;

  const text = await callGemini(apiKey, prompt);
  const json = extractJSON(text);
  return JSON.parse(json) as PanelOutline[];
}

export async function generateStory(
  apiKey: string,
  outlines: PanelOutline[],
  input: GenerationInput
): Promise<PanelStory[]> {
  const outlineText = outlines
    .map(
      (p) =>
        `Panel ${p.panel_number}: ${p.title}\nScene: ${p.scene_description}`
    )
    .join("\n\n");

  const prompt = `You are a comic book storyteller. Based on these panel outlines, write detailed comic content.

Character: "${input.character_name}"
Tone: "${input.tone}"
Art Style: "${input.art_style}"

Panel Outlines:
${outlineText}

Return ONLY a valid JSON object with a "panels" array containing exactly 5 objects. Each object must have:
- "panel_number": integer (1-5)
- "narration": string (narrator text describing action, 1-2 sentences, vivid and engaging)
- "dialogue": string (character speech, use format: "CHARACTER: 'text'" or empty string if no dialogue)
- "caption": string (atmospheric caption, mood-setting phrase, max 15 words)

Make dialogue feel authentic to a ${input.tone.toLowerCase()} comic. Keep narration dynamic.

Return ONLY the JSON object, no other text.`;

  const text = await callGemini(apiKey, prompt);
  const json = extractJSON(text);
  const parsed = JSON.parse(json);
  return parsed.panels as PanelStory[];
}
