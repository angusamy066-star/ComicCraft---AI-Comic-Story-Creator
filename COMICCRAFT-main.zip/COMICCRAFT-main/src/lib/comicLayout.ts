import { PanelOutline, PanelStory, ComicPanel, ComicData, GenerationInput } from "@/types/comic";
import { UNSPLASH_THEMES } from "@/constants/comic";

const UNSPLASH_ACCESS_KEY = "AQ.Ab8RN6LiL4EH1tKABaDbLNC663hwUm-u6-ofcB5ITGA0WSiMUw";

function getImageUrl(panel: PanelOutline, setting: string, artStyle: string, index: number): string {
  // Build a descriptive search query from the panel's image prompt + art style + setting
  const baseTheme = UNSPLASH_THEMES[setting] || UNSPLASH_THEMES["Custom"];
  const promptKeywords = panel.image_prompt
    ? panel.image_prompt.split(" ").slice(0, 6).join("+")
    : baseTheme;
  const styleKeyword = artStyle.toLowerCase().replace(" ", "+");
  const query = encodeURIComponent(`${promptKeywords} ${styleKeyword}`);
  // Use Unsplash random photo API with our key and a per-panel seed for variety
  return `https://api.unsplash.com/photos/random?query=${query}&orientation=landscape&client_id=${UNSPLASH_ACCESS_KEY}&count=1&sig=${index}`;
}

// Resolves the Unsplash API response to a direct image URL
export async function resolveUnsplashUrl(apiUrl: string): Promise<string> {
  try {
    const res = await fetch(apiUrl);
    if (!res.ok) throw new Error(`Unsplash error ${res.status}`);
    const data = await res.json();
    const photo = Array.isArray(data) ? data[0] : data;
    return photo?.urls?.regular || photo?.urls?.small || "";
  } catch (e) {
    console.warn("Unsplash fetch failed, using picsum fallback:", e);
    return "";
  }
}

export function buildComicLayout(
  outlines: PanelOutline[],
  stories: PanelStory[],
  input: GenerationInput
): ComicData {
  const panels: ComicPanel[] = outlines.map((outline, idx) => {
    const story = stories.find((s) => s.panel_number === outline.panel_number) || stories[idx];
    return {
      panel_number: outline.panel_number,
      title: outline.title,
      scene_description: outline.scene_description,
      image_prompt: outline.image_prompt,
      narration: story?.narration || "",
      dialogue: story?.dialogue || "",
      caption: story?.caption || "",
      image_url: getImageUrl(outline, input.setting, input.art_style, idx),
    };
  });

  const titleWords = input.story_prompt.split(" ").slice(0, 5).join(" ");
  const title = `${input.character_name}: ${titleWords}${input.story_prompt.split(" ").length > 5 ? "..." : ""}`;

  return {
    title,
    character_name: input.character_name,
    setting: input.setting,
    tone: input.tone,
    art_style: input.art_style,
    story_prompt: input.story_prompt,
    panels,
  };
}
