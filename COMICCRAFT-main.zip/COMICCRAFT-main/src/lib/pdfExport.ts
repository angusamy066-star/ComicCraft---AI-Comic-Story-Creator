import { ComicData } from "@/types/comic";

export async function exportComicPDF(comic: ComicData): Promise<void> {
  // Dynamically import jsPDF
  const { jsPDF } = await import("jspdf");

  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  const contentWidth = pageWidth - margin * 2;

  // Cover Page
  doc.setFillColor(15, 10, 30);
  doc.rect(0, 0, pageWidth, pageHeight, "F");

  // Title
  doc.setTextColor(180, 100, 255);
  doc.setFontSize(36);
  doc.setFont("helvetica", "bold");
  const titleLines = doc.splitTextToSize(comic.title.toUpperCase(), contentWidth);
  doc.text(titleLines, pageWidth / 2, 60, { align: "center" });

  // Subtitle
  doc.setTextColor(100, 160, 255);
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text("An AI-Powered Comic Story", pageWidth / 2, 80, { align: "center" });

  // Meta info
  doc.setTextColor(200, 200, 220);
  doc.setFontSize(11);
  const metaY = 100;
  doc.text(`Character: ${comic.character_name}`, margin, metaY);
  doc.text(`Setting: ${comic.setting}`, margin, metaY + 7);
  doc.text(`Tone: ${comic.tone}`, margin, metaY + 14);
  doc.text(`Art Style: ${comic.art_style}`, margin, metaY + 21);

  // Story prompt
  doc.setFontSize(10);
  doc.setTextColor(160, 160, 180);
  const promptLines = doc.splitTextToSize(`"${comic.story_prompt}"`, contentWidth);
  doc.text(promptLines, pageWidth / 2, metaY + 40, { align: "center", });

  // COMICCRAFT branding
  doc.setTextColor(120, 80, 200);
  doc.setFontSize(10);
  doc.text("Created with COMICCRAFT — AI Comic Story Creator", pageWidth / 2, pageHeight - 15, { align: "center" });

  // Panel pages
  for (const panel of comic.panels) {
    doc.addPage();

    // Dark background
    doc.setFillColor(15, 10, 30);
    doc.rect(0, 0, pageWidth, pageHeight, "F");

    // Panel header
    doc.setFillColor(80, 40, 160);
    doc.rect(0, 0, pageWidth, 20, "F");

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text(`PANEL ${panel.panel_number} — ${panel.title.toUpperCase()}`, pageWidth / 2, 13, {
      align: "center",
    });

    let yPos = 30;

    // Try to load and add image
    try {
      const imgData = await loadImageAsBase64(panel.image_url);
      if (imgData) {
        const imgWidth = contentWidth;
        const imgHeight = 80;
        doc.addImage(imgData, "JPEG", margin, yPos, imgWidth, imgHeight);
        yPos += imgHeight + 8;
      }
    } catch (e) {
      // Image failed to load, skip
      doc.setFillColor(30, 20, 60);
      doc.rect(margin, yPos, contentWidth, 60, "F");
      doc.setTextColor(100, 80, 160);
      doc.setFontSize(10);
      doc.text("[Comic Panel Illustration]", pageWidth / 2, yPos + 30, { align: "center" });
      yPos += 68;
    }

    // Scene description
    doc.setTextColor(180, 180, 200);
    doc.setFontSize(9);
    doc.setFont("helvetica", "italic");
    const sceneLines = doc.splitTextToSize(`Scene: ${panel.scene_description}`, contentWidth);
    doc.text(sceneLines, margin, yPos);
    yPos += sceneLines.length * 5 + 6;

    // Narration box
    doc.setFillColor(25, 15, 50);
    doc.setDrawColor(100, 60, 200);
    doc.setLineWidth(0.5);
    const narrationLines = doc.splitTextToSize(panel.narration, contentWidth - 10);
    const narBoxHeight = narrationLines.length * 5 + 8;
    doc.roundedRect(margin, yPos, contentWidth, narBoxHeight, 3, 3, "FD");
    doc.setTextColor(220, 200, 255);
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(narrationLines, margin + 5, yPos + 6);
    yPos += narBoxHeight + 6;

    // Dialogue
    if (panel.dialogue) {
      doc.setFillColor(20, 30, 60);
      doc.setDrawColor(60, 120, 255);
      const dialogLines = doc.splitTextToSize(panel.dialogue, contentWidth - 10);
      const dialogBoxHeight = dialogLines.length * 5 + 8;
      doc.roundedRect(margin, yPos, contentWidth, dialogBoxHeight, 3, 3, "FD");
      doc.setTextColor(150, 200, 255);
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.text(dialogLines, margin + 5, yPos + 6);
      yPos += dialogBoxHeight + 6;
    }

    // Caption
    doc.setTextColor(255, 200, 80);
    doc.setFontSize(9);
    doc.setFont("helvetica", "italic");
    doc.text(`"${panel.caption}"`, pageWidth / 2, yPos + 5, { align: "center" });

    // Page footer
    doc.setTextColor(80, 60, 120);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text(`${comic.title} • Panel ${panel.panel_number} of 5`, pageWidth / 2, pageHeight - 8, {
      align: "center",
    });
  }

  // Generate filename
  const now = new Date();
  const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
  const filename = `comic_${timestamp}.pdf`;

  doc.save(filename);
}

async function loadImageAsBase64(url: string): Promise<string | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) { resolve(null); return; }
        ctx.drawImage(img, 0, 0);
        resolve(canvas.toDataURL("image/jpeg", 0.8));
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
    setTimeout(() => resolve(null), 8000);
  });
}
