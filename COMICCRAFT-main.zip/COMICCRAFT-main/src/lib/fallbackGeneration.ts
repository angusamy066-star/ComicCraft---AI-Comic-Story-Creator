import { PanelOutline, PanelStory, GenerationInput } from "@/types/comic";

const DEMO_OUTLINES: Record<string, PanelOutline[]> = {
  default: [
    {
      panel_number: 1,
      title: "The Discovery",
      scene_description:
        "Our hero stands at the edge of a mysterious forest, eyes wide with wonder. A faint glow pulses deep between the ancient trees, beckoning them forward.",
      image_prompt:
        "A brave young fox named Leo wearing a blue scarf stands at the edge of an enchanted forest, golden light filtering through tall trees, comic book art style, dramatic lighting, adventurous mood",
    },
    {
      panel_number: 2,
      title: "Into the Deep Woods",
      scene_description:
        "Venturing deeper, Leo discovers the forest is alive with magic. Glowing mushrooms line the path and fireflies spell out ancient words in the night air.",
      image_prompt:
        "Leo the orange fox with blue scarf walking through an enchanted forest at night, glowing mushrooms, magical fireflies forming patterns, comic book art style, mystical atmosphere",
    },
    {
      panel_number: 3,
      title: "The Glowing Door",
      scene_description:
        "A massive ancient door appears, carved from living wood and pulsing with golden light. Strange symbols glow on its surface. Leo reaches out a paw to touch it.",
      image_prompt:
        "Leo the fox discovering a massive glowing wooden door in an enchanted forest, golden runes glowing, reaching paw forward, comic book art style, dramatic close-up shot, epic moment",
    },
    {
      panel_number: 4,
      title: "Beyond the Threshold",
      scene_description:
        "The door swings open to reveal a breathtaking hidden realm — a world inside the forest, where magical creatures celebrate and ancient spirits dance among floating lanterns.",
      image_prompt:
        "Leo the fox stepping through a magical door into a hidden realm with floating lanterns, magical creatures, ancient spirits dancing, comic book art style, vibrant colors, wonder and awe",
    },
    {
      panel_number: 5,
      title: "A New Adventure Begins",
      scene_description:
        "Embraced by the forest's magical inhabitants, Leo realizes this is just the beginning. With new friends and new powers, a grand adventure awaits in this enchanted world.",
      image_prompt:
        "Leo the fox standing triumphantly with magical forest creatures, enchanted forest background, epic hero pose, comic book art style, warm golden lighting, adventure and hope",
    },
  ],
};

const DEMO_STORIES: Record<string, PanelStory[]> = {
  default: [
    {
      panel_number: 1,
      narration:
        "Deep in the heart of the ancient wilderness, young Leo pauses at the forest's edge — sensing something extraordinary awaits within the shadowed trees.",
      dialogue: "LEO: 'Something's calling to me... I can feel it.'",
      caption: "Every great adventure begins with a single step forward.",
    },
    {
      panel_number: 2,
      narration:
        "The enchanted forest comes alive around Leo, ancient magic swirling through every leaf and root, revealing wonders hidden from ordinary eyes.",
      dialogue:
        "LEO: 'This place... it's like nothing I've ever seen before!'",
      caption: "The forest holds secrets older than memory itself.",
    },
    {
      panel_number: 3,
      narration:
        "There it stands — the legendary Threshold Door, said to open only for those pure of heart. Leo's paw trembles as it touches the glowing surface.",
      dialogue: "LEO: 'The ancient texts were real. It actually exists!'",
      caption: "Some doors, once opened, change everything forever.",
    },
    {
      panel_number: 4,
      narration:
        "Light floods the forest as the door swings wide, revealing a hidden world of breathtaking beauty — a realm where magic flows as freely as a river.",
      dialogue:
        "FOREST SPIRIT: 'We have been waiting for you, brave one. Welcome home.'",
      caption: "Beyond every boundary lies a world waiting to be discovered.",
    },
    {
      panel_number: 5,
      narration:
        "Leo stands at the heart of a new world, surrounded by allies and ancient wonders. The real adventure has only just begun.",
      dialogue:
        "LEO: 'Together, there's nothing we can't face. Let's write our story!'",
      caption: "And so the legend of Leo begins — one panel at a time.",
    },
  ],
};

export function generateFallbackOutline(input: GenerationInput): PanelOutline[] {
  console.log("[FALLBACK MODE] Generating demo outline — no API key provided");
  const base = DEMO_OUTLINES.default;
  return base.map((panel) => ({
    ...panel,
    scene_description: panel.scene_description.replace(/Leo/g, input.character_name || "Leo"),
    image_prompt: panel.image_prompt
      .replace(/Leo the (orange )?fox/g, `${input.character_name || "Leo"}`)
      .replace(/enchanted forest/gi, input.setting || "Enchanted Forest")
      .replace(/comic book/gi, input.art_style || "Comic Book"),
  }));
}

export function generateFallbackStory(
  _outlines: PanelOutline[],
  input: GenerationInput
): PanelStory[] {
  console.log("[FALLBACK MODE] Generating demo story — no API key provided");
  return DEMO_STORIES.default.map((panel) => ({
    ...panel,
    narration: panel.narration.replace(/Leo/g, input.character_name || "Leo"),
    dialogue: panel.dialogue.replace(/LEO/g, (input.character_name || "Leo").toUpperCase()),
  }));
}
