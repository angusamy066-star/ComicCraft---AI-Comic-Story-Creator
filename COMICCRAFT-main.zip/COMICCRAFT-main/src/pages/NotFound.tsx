import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { BookOpen } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-[#0a0515] flex items-center justify-center px-4 text-white">
      <div className="text-center">
        <div className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 mb-4">
          404
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Page Not Found</h2>
        <p className="text-sm text-gray-400 mb-6">
          This page doesn't exist in our comic universe.
        </p>
        <Button
          onClick={() => navigate("/")}
          className="bg-gradient-to-r from-purple-600 to-blue-600 text-white gap-2"
        >
          <BookOpen size={16} />
          Return to COMICCRAFT
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
