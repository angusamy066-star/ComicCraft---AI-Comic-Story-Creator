import { useNavigate } from "react-router-dom";
import { CheckCircle } from "lucide-react";

export default function ExportSuccess() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-md max-w-sm w-full p-8 text-center">
        {/* Check icon */}
        <div className="flex justify-center mb-4">
          <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
            <CheckCircle size={32} className="text-green-500" />
          </div>
        </div>

        <h1 className="text-xl font-black text-green-600 mb-2">
          Comic Exported Successfully!
        </h1>

        <p className="text-sm text-gray-500 mb-6 leading-relaxed">
          Your AI-powered comic has been successfully created! Dive back in and bring another story to life.
        </p>

        <button
          onClick={() => navigate("/")}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl transition-colors"
        >
          Go Create Another Comic
        </button>

        <button
          onClick={() => navigate("/preview")}
          className="mt-3 w-full border border-gray-200 text-gray-500 hover:bg-gray-50 font-medium py-2.5 rounded-xl transition-colors text-sm"
        >
          View Comic Again
        </button>
      </div>
    </div>
  );
}
