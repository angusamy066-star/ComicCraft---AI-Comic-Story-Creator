import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useStoredComic } from "@/hooks/useComicGeneration";
import ComicPanelCard from "@/components/features/ComicPanel";
import { exportComicPDF } from "@/lib/pdfExport";
import { Download, ArrowLeft, BookOpen } from "lucide-react";
import { toast } from "sonner";

export default function ComicPreview() {
  const navigate = useNavigate();
  const comic = useStoredComic();
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    if (!comic) navigate("/");
  }, [comic, navigate]);

  if (!comic) return null;

  async function handleDownloadPDF() {
    if (!comic) return;
    setIsExporting(true);
    try {
      await exportComicPDF(comic);
      toast.success("PDF exported successfully!");
      setTimeout(() => navigate("/export-success"), 800);
    } catch (e) {
      console.error("PDF export error:", e);
      toast.error("Failed to export PDF. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top nav bar */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 transition-colors group"
          >
            <ArrowLeft size={15} className="group-hover:-translate-x-0.5 transition-transform" />
            Back
          </button>

          <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
            <BookOpen size={16} className="text-blue-600" />
            Your Comic Preview
          </div>

          <button
            onClick={handleDownloadPDF}
            disabled={isExporting}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors disabled:opacity-60"
          >
            {isExporting ? (
              <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              <Download size={13} />
            )}
            {isExporting ? "Exporting..." : "Export PDF"}
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Comic title */}
        <div className="mb-6 text-center">
          <h1 className="text-2xl sm:text-3xl font-black text-gray-900 mb-2">{comic.title}</h1>
          <div className="flex flex-wrap justify-center gap-2 text-xs text-gray-500">
            <span>{comic.character_name}</span>
            <span>•</span>
            <span>{comic.setting}</span>
            <span>•</span>
            <span>{comic.tone}</span>
            <span>•</span>
            <span>{comic.art_style}</span>
          </div>
        </div>

        {/* Panels list */}
        <div className="space-y-4 mb-10">
          {comic.panels.map((panel) => (
            <ComicPanelCard key={panel.panel_number} panel={panel} />
          ))}
        </div>

        {/* Download CTA */}
        <div className="bg-white border border-gray-200 rounded-2xl p-6 text-center shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-1">
            Ready to save your comic?
          </h3>
          <p className="text-sm text-gray-500 mb-5">
            Download as a PDF to share or print your AI-generated comic.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3">
            <button
              onClick={handleDownloadPDF}
              disabled={isExporting}
              className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-xl transition-colors disabled:opacity-60"
            >
              {isExporting ? (
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                <Download size={17} />
              )}
              Download Your Comic as PDF
            </button>
            <button
              onClick={() => navigate("/")}
              className="flex items-center justify-center gap-2 border border-gray-300 text-gray-600 hover:bg-gray-50 font-medium px-8 py-3 rounded-xl transition-colors"
            >
              Create Another Comic
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
