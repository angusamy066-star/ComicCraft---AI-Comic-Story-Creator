import ComicForm from "@/components/features/ComicForm";
import LoadingScreen from "@/components/features/LoadingScreen";
import { useComicGeneration } from "@/hooks/useComicGeneration";
import { GenerationInput } from "@/types/comic";
import { toast } from "sonner";
import { useEffect } from "react";

const heroBg = new URL("../assets/hero-bg.jpg", import.meta.url).href;

export default function Index() {
  const { step, error, generate, reset } = useComicGeneration();
  const isLoading = step !== "idle" && step !== "error";

  useEffect(() => {
    if (error) {
      toast.error(error);
      reset();
    }
  }, [error]);

  function handleGenerate(input: GenerationInput, apiKey: string) {
    generate(input, apiKey);
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Full-screen nature background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      {/* Subtle overlay to soften image */}
      <div className="absolute inset-0 bg-white/10" />

      {/* Loading overlay */}
      {isLoading && <LoadingScreen step={step} />}

      {/* Centered form card */}
      <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-sm">
          {/* White card */}
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            {/* Card title */}
            <div className="flex items-center gap-2 mb-6">
              <span className="text-blue-600 text-lg">✏️</span>
              <h1 className="text-xl font-bold text-gray-800">Create Your Comic</h1>
            </div>

            <ComicForm onSubmit={handleGenerate} isLoading={isLoading} />
          </div>
        </div>
      </div>
    </div>
  );
}
