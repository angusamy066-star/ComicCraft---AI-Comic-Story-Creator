import { useState } from "react";
import { ComicData, GenerationInput, GenerationStep } from "@/types/comic";
import { generateOutline, generateStory } from "@/lib/gemini";
import { generateFallbackOutline, generateFallbackStory } from "@/lib/fallbackGeneration";
import { buildComicLayout, resolveUnsplashUrl } from "@/lib/comicLayout";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export function useComicGeneration() {
  const navigate = useNavigate();
  const [step, setStep] = useState<GenerationStep>("idle");
  const [error, setError] = useState<string | null>(null);

  async function generate(input: GenerationInput, apiKey: string) {
    setStep("outline");
    setError(null);

    try {
      let outlines;
      let stories;
      const hasApiKey = apiKey.trim().length > 0;

      // Generate outline
      if (hasApiKey) {
        try {
          outlines = await generateOutline(apiKey, input);
        } catch (e) {
          console.warn("Gemini outline generation failed, using fallback:", e);
          toast.warning("API generation failed, using demo mode.");
          outlines = generateFallbackOutline(input);
        }
      } else {
        outlines = generateFallbackOutline(input);
      }

      setStep("story");

      // Generate story
      if (hasApiKey) {
        try {
          stories = await generateStory(apiKey, outlines, input);
        } catch (e) {
          console.warn("Gemini story generation failed, using fallback:", e);
          stories = generateFallbackStory(outlines, input);
        }
      } else {
        stories = generateFallbackStory(outlines, input);
      }

      setStep("images");

      // Build layout first (with Unsplash API URLs)
      const comicRaw = buildComicLayout(outlines, stories, input);

      // Resolve all Unsplash API endpoints to real image URLs in parallel
      const resolvedPanels = await Promise.all(
        comicRaw.panels.map(async (panel) => {
          if (panel.image_url.includes("api.unsplash.com")) {
            const resolved = await resolveUnsplashUrl(panel.image_url);
            return { ...panel, image_url: resolved || `https://picsum.photos/seed/comiccraft${panel.panel_number}/800/600` };
          }
          return panel;
        })
      );

      setStep("layout");

      const comic = { ...comicRaw, panels: resolvedPanels };

      await new Promise((r) => setTimeout(r, 800));

      setStep("done");

      // Store and navigate
      localStorage.setItem("comiccraft_current", JSON.stringify(comic));
      await new Promise((r) => setTimeout(r, 600));
      navigate("/preview");
    } catch (e) {
      console.error("Comic generation error:", e);
      setError("Something went wrong while creating your comic. Please try again.");
      setStep("error");
    }
  }

  function reset() {
    setStep("idle");
    setError(null);
  }

  return { step, error, generate, reset };
}

export function useStoredComic(): ComicData | null {
  try {
    const data = localStorage.getItem("comiccraft_current");
    if (!data) return null;
    return JSON.parse(data) as ComicData;
  } catch {
    return null;
  }
}
