export interface PanelOutline {
  panel_number: number;
  title: string;
  scene_description: string;
  image_prompt: string;
}

export interface PanelStory {
  panel_number: number;
  narration: string;
  dialogue: string;
  caption: string;
}

export interface ComicPanel {
  panel_number: number;
  title: string;
  scene_description: string;
  image_prompt: string;
  narration: string;
  dialogue: string;
  caption: string;
  image_url: string;
}

export interface ComicData {
  title: string;
  character_name: string;
  setting: string;
  tone: string;
  art_style: string;
  story_prompt: string;
  panels: ComicPanel[];
  pdf_filename?: string;
}

export interface GenerationInput {
  story_prompt: string;
  character_name: string;
  setting: string;
  tone: string;
  art_style: string;
}

export type GenerationStep =
  | "idle"
  | "outline"
  | "story"
  | "images"
  | "layout"
  | "done"
  | "error";
