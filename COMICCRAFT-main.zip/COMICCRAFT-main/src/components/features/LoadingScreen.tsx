import { GenerationStep } from "@/types/comic";
import { LOADING_STEPS } from "@/constants/comic";

interface LoadingScreenProps {
  step: GenerationStep;
}

export default function LoadingScreen({ step }: LoadingScreenProps) {
  const stepIndex = LOADING_STEPS.findIndex((s) => s.key === step);
  const currentLabel = LOADING_STEPS.find((s) => s.key === step)?.label || "Processing...";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full mx-4 p-8">
        {/* Spinner */}
        <div className="flex justify-center mb-5">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-4 border-blue-100 border-t-blue-600 animate-spin" />
            <div className="absolute inset-3 rounded-full border-4 border-gray-100 border-b-indigo-400 animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.2s" }} />
          </div>
        </div>

        <h3 className="text-center text-lg font-bold text-gray-800 mb-1">
          Creating Your Comic
        </h3>
        <p className="text-center text-sm text-blue-600 mb-6 font-medium">
          {currentLabel}
        </p>

        {/* Progress steps */}
        <div className="space-y-2">
          {LOADING_STEPS.map((s, idx) => {
            const isPast = stepIndex > idx;
            const isCurrent = stepIndex === idx;
            return (
              <div
                key={s.key}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                  isCurrent ? "bg-blue-50 border border-blue-100" : ""
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all ${
                    isPast
                      ? "bg-green-500 text-white"
                      : isCurrent
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {isPast ? "✓" : idx + 1}
                </div>
                <span
                  className={`text-sm ${
                    isCurrent ? "text-gray-800 font-semibold" : "text-gray-400"
                  }`}
                >
                  {s.label}
                </span>
                {isCurrent && (
                  <div className="ml-auto flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
