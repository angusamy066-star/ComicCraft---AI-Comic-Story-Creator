import { ComicPanel as ComicPanelType } from "@/types/comic";
import { useState } from "react";

interface ComicPanelProps {
  panel: ComicPanelType;
}

export default function ComicPanelCard({ panel }: ComicPanelProps) {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      {/* Panel header */}
      <div className="px-4 py-3 border-b border-gray-100">
        <h3 className="text-sm font-bold text-gray-800">
          Panel {panel.panel_number}: {panel.title}
        </h3>
      </div>

      <div className="flex flex-col sm:flex-row">
        {/* Image */}
        <div className="relative sm:w-48 flex-shrink-0 bg-gray-100">
          <div className="aspect-[4/3] sm:aspect-auto sm:h-full min-h-[140px]">
            {!imgLoaded && !imgError && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                <div className="w-6 h-6 border-2 border-blue-400/30 border-t-blue-500 rounded-full animate-spin" />
              </div>
            )}
            {imgError ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
                <div className="text-3xl mb-1">🎨</div>
                <p className="text-xs text-gray-400">Panel {panel.panel_number}</p>
              </div>
            ) : (
              <img
                src={panel.image_url}
                alt={panel.title}
                className={`w-full h-full object-cover transition-opacity duration-500 ${
                  imgLoaded ? "opacity-100" : "opacity-0"
                }`}
                onLoad={() => setImgLoaded(true)}
                onError={() => setImgError(true)}
              />
            )}
          </div>
        </div>

        {/* Text content */}
        <div className="flex-1 px-4 py-3 space-y-2 min-w-0">
          {/* Scene description */}
          {panel.scene_description && (
            <p className="text-xs text-gray-500 italic leading-relaxed">
              {panel.scene_description}
            </p>
          )}

          {/* Narration */}
          {panel.narration && (
            <p className="text-xs text-gray-700 leading-relaxed">
              <span className="font-semibold text-gray-500">NARRATION: </span>
              {panel.narration}
            </p>
          )}

          {/* Dialogue */}
          {panel.dialogue && (
            <div className="bg-blue-50 border border-blue-100 rounded-lg px-3 py-1.5">
              <p className="text-xs text-blue-800 leading-relaxed font-medium">
                {panel.dialogue}
              </p>
            </div>
          )}

          {/* Caption */}
          {panel.caption && (
            <p className="text-xs text-amber-600 italic border-t border-gray-100 pt-2">
              Caption: "{panel.caption}"
            </p>
          )}

          {/* Image prompt ref */}
          {panel.image_prompt && (
            <p className="text-xs text-gray-400 border-t border-gray-100 pt-2 truncate">
              <span className="font-medium">Image ref:</span> {panel.image_prompt}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
