import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { SETTINGS, TONES, ART_STYLES, DEMO_COMIC_DATA } from "@/constants/comic";
import { GenerationInput } from "@/types/comic";
import { Key, Loader2 } from "lucide-react";

const schema = z.object({
  story_prompt: z.string().min(10, "Please describe your story (at least 10 characters)"),
  character_name: z.string().min(1, "Character name is required"),
  setting: z.string().min(1, "Please select a setting"),
  tone: z.string().min(1, "Please select a tone"),
  art_style: z.string().min(1, "Please select an art style"),
  api_key: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

interface ComicFormProps {
  onSubmit: (input: GenerationInput, apiKey: string) => void;
  isLoading: boolean;
}

const inputBase =
  "w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white";

const labelBase = "block text-xs font-semibold text-gray-600 mb-1";

export default function ComicForm({ onSubmit, isLoading }: ComicFormProps) {
  const [showApiKey, setShowApiKey] = useState(false);
  const savedKey = localStorage.getItem("comiccraft_api_key") || "";

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      story_prompt: "",
      character_name: "",
      setting: "",
      tone: "",
      art_style: "",
      api_key: savedKey,
    },
  });

  function fillDemo() {
    setValue("story_prompt", DEMO_COMIC_DATA.story_prompt);
    setValue("character_name", DEMO_COMIC_DATA.character_name);
    setValue("setting", DEMO_COMIC_DATA.setting);
    setValue("tone", DEMO_COMIC_DATA.tone);
    setValue("art_style", DEMO_COMIC_DATA.art_style);
  }

  function onFormSubmit(data: FormData) {
    if (data.api_key) {
      localStorage.setItem("comiccraft_api_key", data.api_key);
    }
    onSubmit(
      {
        story_prompt: data.story_prompt,
        character_name: data.character_name,
        setting: data.setting,
        tone: data.tone,
        art_style: data.art_style,
      },
      data.api_key || ""
    );
  }

  const apiKey = watch("api_key");

  return (
    <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
      {/* Story Prompt */}
      <div>
        <label className={labelBase}>Story Prompt</label>
        <textarea
          {...register("story_prompt")}
          rows={3}
          placeholder="A brave fox exploring an enchanted forest..."
          className={`${inputBase} resize-none`}
        />
        {errors.story_prompt && (
          <p className="text-red-500 text-xs mt-1">{errors.story_prompt.message}</p>
        )}
      </div>

      {/* Character Name */}
      <div>
        <label className={labelBase}>Main Character Name</label>
        <input
          {...register("character_name")}
          placeholder="Leo"
          className={inputBase}
        />
        {errors.character_name && (
          <p className="text-red-500 text-xs mt-1">{errors.character_name.message}</p>
        )}
      </div>

      {/* Setting */}
      <div>
        <label className={labelBase}>Setting:</label>
        <select
          defaultValue=""
          onChange={(e) => setValue("setting", e.target.value, { shouldValidate: true })}
          className={inputBase}
        >
          <option value="" disabled>Forest</option>
          {SETTINGS.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        {errors.setting && (
          <p className="text-red-500 text-xs mt-1">{errors.setting.message}</p>
        )}
      </div>

      {/* Story Tone */}
      <div>
        <label className={labelBase}>Story Tone</label>
        <select
          defaultValue=""
          onChange={(e) => setValue("tone", e.target.value, { shouldValidate: true })}
          className={inputBase}
        >
          <option value="" disabled>Humour</option>
          {TONES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        {errors.tone && (
          <p className="text-red-500 text-xs mt-1">{errors.tone.message}</p>
        )}
      </div>

      {/* Art Style */}
      <div>
        <label className={labelBase}>Art Style:</label>
        <select
          defaultValue=""
          onChange={(e) => setValue("art_style", e.target.value, { shouldValidate: true })}
          className={inputBase}
        >
          <option value="" disabled>Comic Art</option>
          {ART_STYLES.map((a) => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
        {errors.art_style && (
          <p className="text-red-500 text-xs mt-1">{errors.art_style.message}</p>
        )}
      </div>

      {/* API Key */}
      <div>
        <button
          type="button"
          onClick={() => setShowApiKey(!showApiKey)}
          className="flex items-center gap-1.5 text-xs text-blue-500 hover:text-blue-700 transition-colors"
        >
          <Key size={11} />
          {showApiKey ? "Hide" : "Add"} Gemini API Key (optional)
        </button>
        {showApiKey && (
          <div className="mt-2 space-y-1">
            <input
              {...register("api_key")}
              type="password"
              placeholder="AIza..."
              className={`${inputBase} text-xs`}
            />
            {!apiKey && (
              <p className="text-xs text-amber-600">
                Without a key, demo mode generates a full comic.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Buttons row */}
      <div className="flex gap-2 pt-1">
        <button
          type="button"
          onClick={fillDemo}
          disabled={isLoading}
          className="px-4 py-2 text-sm border border-gray-300 rounded-md text-gray-600 hover:bg-gray-50 transition-colors disabled:opacity-50"
        >
          Demo
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold py-2.5 rounded-md transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {isLoading ? (
            <>
              <Loader2 size={15} className="animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Comic"
          )}
        </button>
      </div>
    </form>
  );
}
