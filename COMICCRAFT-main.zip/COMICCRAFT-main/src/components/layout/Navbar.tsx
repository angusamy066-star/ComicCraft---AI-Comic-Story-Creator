import { Link, useNavigate } from "react-router-dom";
import { BookOpen } from "lucide-react";

export default function Navbar() {
  const navigate = useNavigate();

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-sm border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <BookOpen size={16} className="text-white" />
          </div>
          <span className="text-gray-800 font-extrabold text-lg tracking-tight">
            COMIC<span className="text-blue-600">CRAFT</span>
          </span>
        </Link>

        <button
          onClick={() => navigate("/")}
          className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
        >
          + New Comic
        </button>
      </div>
    </nav>
  );
}
